<?php

namespace controllers;
use model\ReviewModel;
include(__DIR__ . '/../model/ReviewModel.php');
class ReviewController
{
    private $reviewModel;
    public function __construct($reviewModel){
        $this->reviewModel = $reviewModel;
    }
    public function listReviews(){
        return $this->reviewModel->listAllReviews();
    }
    public function addReview($article_id, $user_id){
        $this->reviewModel->addReview($article_id, $user_id);
    }
    public function articleReviewersCount($article_id)
    {
        return $this->reviewModel->articleReviewersCount($article_id);
    }
    public function setReview($review_id, $total, $language, $content, $novelty, $comment){
        // ensure numeric values are present and within 1..5 range
        if (!is_numeric($total) || !is_numeric($language) || !is_numeric($content) || !is_numeric($novelty)) {
            return false;
        }

        $total = (float)$total;
        $language = (float)$language;
        $content = (float)$content;
        $novelty = (float)$novelty;

        if ($total >= 1 && $total <= 5 && $novelty >= 1 && $novelty <= 5 && $content >= 1 && $content <= 5 && $language >= 1 && $language <= 5) {
            return $this->reviewModel->setReview($review_id, $total, $language, $content, $novelty, $comment);
        }

        // validation failed
        return false;
    }
    public function listAllArticleReviews($article_id)
    {
        return $this->reviewModel->listAllArticleReviews($article_id);
    }
    public function deleteReview($review_id){
        $this->reviewModel->deleteReview($review_id);
    }
    public function hasUserReview($user_id, $article_id)
    {
        return $this->reviewModel->hasUserReview($user_id, $article_id);
    }
}