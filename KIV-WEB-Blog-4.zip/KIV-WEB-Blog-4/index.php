<?php
session_start();

// tabulka s php co jsou ve views
$allowed = [
    'home' => 'home.php',
    'login' => 'login.php',
    'register' => 'register.php',
    'logout' => 'logout.php',
    'user-home' => 'user-home-page.php',
    'review-home' => 'review-home-page.php',
    'articleadd' => 'articleadd.php',
    'admin-users' => 'admin-users.php',
    'admin-reviews' => 'admin-reviews.php'
];

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
// timhle ziskam url aktualni stranky

// ziskam hodnotu z allowed
if (!array_key_exists($page, $allowed)) {
    // neplatná stránka
    http_response_code(404);
    echo "Stránka nenalezena (404).";
    exit;
}

// file = kouknu se do views a najdu odpovídající soubor
$viewFile = __DIR__ . '/views/' . $allowed[$page];
if (!file_exists($viewFile)) {
    // php neexistuje
    http_response_code(500);
    echo "Chyba: view file neexistuje.";
    exit;
}

// includne se požadovaný soubor
include $viewFile;
