<?php
use controllers\ArticleController;
use controllers\ReviewController;
use controllers\UserController;
use model\ArticleModel;
use model\ReviewModel;
use model\UserModel;

global $conn;
include(__DIR__ . '/../dbconfig.php');
include(__DIR__ . '/../controllers/ArticleController.php');
include(__DIR__ . '/../controllers/ReviewController.php');
include(__DIR__ . '/../controllers/UserController.php');
$message = "";
$modifyarticlemessage = "";

// session is started in front controller (index.php)
$articleModel = new ArticleModel($conn);
$listController = new ArticleController($articleModel);
$articles = $listController->listAllArticlesByUser();

$reviewModel = new ReviewModel($conn);
$reviewController = new ReviewController($reviewModel);

$userModel = new UserModel($conn);
$userController = new UserController($userModel);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['akce'])) {
    $akce = $_POST['akce'];
    $article_id = $_POST['article_id'];

    if ($akce === 'upravit') {
        $article_name = $_POST['article_name'];
        $abstract = $_POST['abstract'];
        $authors = $_POST['authors'];

    $listController->remakeArticle($article_id, $article_name, $abstract, $authors);
    header("Location: index.php?page=user-home");
    } elseif ($akce === 'odebrat') {
        $listController->deleteArticleById($article_id);
    }
}

?>


    <!DOCTYPE html>
    <html lang="cs">
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="views/styles/user-home-page.css?v=1.2">
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    </head>
    <body>

    <nav class="navbar">
        <div class="navbar-brand">
            <a href="index.php?page=user-home">Moje Webová Stránka</a>
        </div>
        <ul class="navbar-menu">
            <li><a href="index.php?page=user-home">Publikované články</a></li>
            <?php if(isset($_SESSION['login'])): ?>
                <li>
                    <?php echo htmlspecialchars($_SESSION['name'] . " " . $_SESSION['surname']); ?>
                </li>
                <li>
                    <form action="index.php?page=logout" method="post">
                                <button type="submit" class="btn btn-light">Odhlásit se</button>
                            </form>
                </li>
            <?php endif; ?>

        </ul>
    </nav>

    <main class="user-home">


        <?php if(isset($_SESSION['login'])): ?>
            <section class="home-header">

                <?php if($_SESSION['userRole'] == 1): ?>
                    <!-- Use a direct link instead of a form to avoid nested-form/JS interference -->
                    <a href="index.php?page=articleadd" class="btn btn-primary add-article-form">Přidat článek</a>
                <?php endif; ?>
                
                <!-- editor will be initialized inside edit forms when "Upravit" is clicked -->
            </section>
        <?php else: ?>
            <section class="guest-message">
                <h1>Jste zde jako nepřihlášený uživatel</h1>
                <form action="index.php?page=login" method="get">
                    <button type="submit" class="btn btn-primary">Přihlásit se</button>
                </form>
            </section>
        <?php endif; ?>


        <section class="articles-section">
            <h1 class="section-title">Publikované články</h1>

            <?php if (!empty($articles)): ?>
                <ul class="articles-list">
                    <?php foreach ($articles as $article): ?>
                        <?php $foreign_reviews = $reviewController->listAllArticleReviews($article['article_id']); ?>

                        <li class="article-card">

                            <h3>
                                <strong style="color: #007BFF; font-weight: bold;">
                                    <?= htmlspecialchars($article['authors']) . ": " . htmlspecialchars($article['article_name']); ?>
                                </strong>
                            </h3>
                            <p class="article-abstract"><?= htmlspecialchars($article['abstract']) ?></p>

                            <button type="button"
                                    class="btn btn-outline-primary toggle-btn"
                                    data-target="content-<?= $article['article_id'] ?>">
                                Zobrazit
                            </button>

                            <div id="content-<?= $article['article_id'] ?>" class="toggle-content">

                                <!-- PDF soubor -->
                                <div class="pdf-container">
                                    <?php
                                    // Normalize stored file path so iframe works regardless of how it was saved
                                    $pdfUrl = $article['file'] ?? '';
                                    if (strpos($pdfUrl, '../') === 0) {
                                        $pdfUrl = substr($pdfUrl, 3);
                                    } elseif (strpos($pdfUrl, './') === 0) {
                                        $pdfUrl = substr($pdfUrl, 2);
                                    }
                                    ?>
                                    <iframe src="<?= htmlspecialchars($pdfUrl) ?>" class="pdf-frame"></iframe>
                                </div>

                                <!-- Sekce dalších recenzí -->
                                <?php if (!empty($foreign_reviews)): ?>
                                    <div class="other-reviews">
                                        <strong>Další recenze:</strong>
                                        <div class="reviews-list">
                                            <?php foreach ($foreign_reviews as $f_review): ?>
                                                <?php
                                                $reviewer = $userController->getNameById($f_review['user_id']);
                                                $reviewName = $reviewer['name'] === $_SESSION['login'] ? "Moje recenze" : $reviewer['name'] . " " . $reviewer['surname'];
                                                ?>
                                                <div class="review-badge">
                                                    <?= htmlspecialchars($reviewName) ?>
                                                    <span class="stars">
                                                    <?php
                                                    $f_rating = (int)$f_review['total'];
                                                    for ($i=1; $i<=5; $i++) echo $i <= $f_rating ? '★' : '☆';
                                                    ?>
                                                </span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Akční tlačítka -->
                            <div class="article-actions">

                                <!-- Upravit článek -->
                                <button type="button"
                                        class="btn btn-secondary edit-btn"
                                        data-target="edit-<?= $article['article_id'] ?>">
                                    Upravit
                                </button>

                                <!-- Formulář pro úpravu -->
                                <div id="edit-<?= $article['article_id'] ?>" class="edit-content">
                                    <form action="index.php?page=user-home" method="post" enctype="multipart/form-data" class="edit-article-form">
                                        <input type="hidden" name="article_id" value="<?= htmlspecialchars($article['article_id']) ?>">

                                        <label>Název článku:</label>
                                        <input type="text" name="article_name" value="<?= htmlspecialchars($article['article_name']) ?>" required>

                                        <label>Autoři článku:</label>
                                        <input type="text" name="authors" value="<?= htmlspecialchars($article['authors']) ?>" required>

                                        <label>Abstrakt:</label>
                                        <textarea id="abstract-<?= $article['article_id'] ?>" name="abstract" rows="4" required><?= htmlspecialchars($article['abstract']) ?></textarea>

                                        <button type="submit" name="akce" value="upravit" class="btn btn-success">Uložit změny</button>
                                    </form>
                                </div>

                                <form action="index.php?page=user-home" method="POST" class="delete-article-form">
                                    <input type="hidden" name="akce" value="odebrat">
                                    <input type="hidden" name="article_id" value="<?= htmlspecialchars($article['article_id']) ?>">
                                    <button type="submit" class="btn btn-danger">Odebrat</button>
                                </form>

                                <!-- Zprávy -->
                                <div class="message">
                                    <label><?= htmlspecialchars($modifyarticlemessage) ?></label>
                                </div>
                            </div>

                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="no-articles">Žádné články nebyly nalezeny.</p>
            <?php endif; ?>
        </section>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoYz1HkQK7U5q2b7rZl+3G1F5i5jv5Q5nQvZ6jIW3" crossorigin="anonymous"></script>
    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const buttons = document.querySelectorAll(".toggle-btn");

            buttons.forEach(button => {
                button.addEventListener("click", () => {
                    const targetId = button.getAttribute("data-target");
                    const target = document.getElementById(targetId);

                    if (target.style.display === "none" || target.style.display === "") {
                        target.style.display = "block";
                        button.textContent = "Skrýt";
                    } else {
                        target.style.display = "none";
                        button.textContent = "Zobrazit";
                    }
                });
            });
        });
    </script>

    <script src="https://cdn.ckeditor.com/4.21.0/full-all/ckeditor.js"></script>
    <script>
        (function(){
            function initEditorForTextarea(textarea) {
            if (!textarea) return;
            var id = textarea.id;
            if (typeof CKEDITOR === 'undefined') return;
            if (!CKEDITOR.instances[id]) {
                CKEDITOR.replace(id, {
                    versionCheck: false,
                    extraPlugins: 'font',
                    toolbar: [
                        { name: 'styles', items: [ 'Font', 'FontSize' ] },
                        { name: 'basicstyles', items: [ 'Bold', 'Italic', 'Underline', 'Strike' ] },
                        { name: 'paragraph', items: [ 'BulletedList', 'NumberedList' ] },
                        { name: 'links', items: [ 'Link', 'Unlink' ] },
                        { name: 'insert', items: [ 'Image', 'Table' ] },
                        { name: 'tools', items: [ 'Maximize' ] }
                    ]
                });
            }
        }

            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const target = document.getElementById(btn.dataset.target);
                    const willShow = (target.style.display === 'none' || target.style.display === '');
                    target.style.display = willShow ? 'block' : 'none';
                    if (willShow) {
                        const textarea = target.querySelector('textarea[name="abstract"]');
                        if (textarea) initEditorForTextarea(textarea);
                    }
                });
            });

            document.querySelectorAll('.edit-article-form').forEach(form => {
                form.addEventListener('submit', function() {
                    if (typeof CKEDITOR !== 'undefined') {
                        for (var name in CKEDITOR.instances) {
                            if (CKEDITOR.instances.hasOwnProperty(name)) {
                                CKEDITOR.instances[name].updateElement();
                            }
                        }
                    }
                });
            });
        })();
    </script>
    <script>
        CKEDITOR.replace('editor1', {
            versionCheck: false
        });
    </script>

    <script>
        $(document).ready(function() {
            $('.delete-article-form').on('submit', function(e) {
                if (!confirm('Opravdu chcete položku smazat?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
    </body>
</html>
