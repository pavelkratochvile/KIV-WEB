<?php
use controllers\UserController;
use model\UserModel;

global $conn;
include(__DIR__ . '/../dbconfig.php');
include(__DIR__ . '/../controllers/UserController.php');
$message = "";

// session is started in front controller (index.php)
$userModel = new UserModel($conn);
$userController = new UserController($userModel);

if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $surname = trim($_POST['surname']);
    $login = trim($_POST['login']);
    $email = trim($_POST['email']);

    $password1 = trim($_POST['password-reg1']);
    $password2 = trim($_POST['password-reg2']);

    if($password1 != $password2) {
        $message = "Hesla se neshodují!";
    }
    else{
        $password = password_hash($password1, PASSWORD_DEFAULT);
        $message = $userController->register($name, $surname, $login, $email, $password);
    }
}
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title>Registrace</title>
    <link rel="stylesheet" href="views/styles/register.css">
</head>
<body>
<div class="form-container">
    <h1>Registrace</h1>
    <form action="index.php?page=register" method="post">
        <label>Jméno</label>
        <input type="text" name="name" required>

        <label>Příjmení</label>
        <input type="text" name="surname" required>

        <label>Přihlašovací jméno</label>
        <input type="text" name="login" required>

        <label>Heslo</label>
        <input type="password" name="password-reg1" required>

        <label>Heslo</label>
        <input type="password" name="password-reg2" required>

        <label>Email</label>
        <input type="email" name="email" required>

    <input type="submit" name="register" value="Registrovat" class="btn btn-primary">
    </form>

    <form action="index.php?page=login" method="get">
        <button type="submit" class="btn btn-light">Přihlásit se</button>
    </form>

    <?php if(!empty($message)) : ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>
</div>
</body>
</html>

