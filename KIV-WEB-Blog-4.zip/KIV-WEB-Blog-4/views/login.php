<?php

use controllers\UserController;
use model\UserModel;

global $conn;
include(__DIR__ . '/../dbconfig.php');
include(__DIR__ . '/../controllers/UserController.php');
$message = "";

$UserModel = new UserModel($conn);
$userController = new UserController($UserModel);

if(isset($_POST['log-but'])){
    $login = $_POST["login"];
    $password = $_POST["password"];
    $message = $userController->login($login, $password);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Přihlášení</title>
    <link rel="stylesheet" href="views/styles/login.css">
</head>
<body>
<div class="form-container">
    <h2>Přihlášení</h2>

    <form action="index.php?page=login" method="post">
        <label for="login">Jméno</label>
        <input type="text" id="login" name="login" required>

        <label for="password">Heslo</label>
        <input type="password" id="password" name="password" required>

    <input type="submit" name="log-but" value="Přihlásit se" class="btn btn-primary">
    </form>


    <form action="index.php?page=register" method="get">
        <button type="submit" class="btn btn-light">Registrovat se</button>
    </form>
    <?php if(!empty($message)) : ?>
        <p style="color:red;"><?php echo $message; ?></p>
    <?php endif; ?>
</div>
</body>
</html>


