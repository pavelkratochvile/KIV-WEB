<?php

use controllers\ReviewController;
use controllers\ArticleController;
use controllers\UserController;
use model\ReviewModel;
use model\ArticleModel;
use model\UserModel;

global $conn;
include(__DIR__ . '/../dbconfig.php');
include(__DIR__ . '/../controllers/ReviewController.php');
include(__DIR__ . '/../controllers/ArticleController.php');
include(__DIR__ . '/../controllers/UserController.php');

$message = "";

// session is started in front controller (index.php)
$reviewModel = new ReviewModel($conn);
$reviewController = new ReviewController($reviewModel);
$reviews = $reviewController->listReviews();

$articleModel = new ArticleModel($conn);
$articleController = new ArticleController($articleModel);

$userModel = new UserModel($conn);
$userController = new UserController($userModel);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id'])) {
    // Bezpečné načtení hodnot (bez ?? pro kompatibilitu)
    $review_id = (int) $_POST['review_id'];
    $total     = isset($_POST['total']) ? $_POST['total'] : null;
    $language  = isset($_POST['language']) ? $_POST['language'] : null;
    $content   = isset($_POST['content']) ? $_POST['content'] : null;
    $novelty   = isset($_POST['novelty']) ? $_POST['novelty'] : null;
    $comment   = isset($_POST['comment']) ? $_POST['comment'] : '';

    // Normalize decimal comma to dot (users may type 4,5)
    if ($total !== null)    $total = str_replace(',', '.', $total);
    if ($language !== null) $language = str_replace(',', '.', $language);
    if ($content !== null)  $content = str_replace(',', '.', $content);
    if ($novelty !== null)  $novelty = str_replace(',', '.', $novelty);

    // Volitelně přetypovat (controller provede konečnou validaci)
    // Zavoláme controller a zkontrolujeme, zda došlo k uložení
    $ok = $reviewController->setReview($review_id, $total, $language, $content, $novelty, $comment);

    if ($ok) {
        $message = "Recenze úspěšně uložena.";
    } else {
        $message = "Chyba při ukládání recenze. Zkontrolujte, že všechna hodnocení jsou čísla v rozmezí 1–5.";
    }
}

?>


<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <!-- Bootstrap Icons for consistent iconography -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="views/styles/review-home-page.css?v=1.2">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>


<nav class="navbar">
    <div class="navbar-brand">
    <a href="index.php?page=review-home">Moje Webová Stránka</a>
    </div>
    <ul class="navbar-menu">
    <li><a href="index.php?page=review-home">Home</a></li>
        <?php if(isset($_SESSION['login'])): ?>
            <li>
                <?php echo htmlspecialchars($_SESSION['name'] . " " . $_SESSION['surname']); ?>
            </li>
            <li>
                <form action="index.php?page=logout" method="post">
                    <button type="submit" class="btn btn-light">Odhlásit se</button>
                </form>
            </li>
        <?php endif; ?>

    </ul>
</nav>

<h1 class="reviews-title">Publikované recenze</h1>

<?php if (!empty($message)): ?>
    <div class="container mt-2">
        <div class="alert alert-info" role="alert"><?php echo htmlspecialchars($message); ?></div>
    </div>
<?php endif; ?>

<?php if (!empty($reviews)): ?>
    <ul class="reviews-list">
        <?php foreach ($reviews as $review): ?>
            <?php $currentArticle = $articleController->getArticleById($review['article_id']); ?>
            <li class="review-item">
                <div class="review-card">

                    <?php
                    $foreign_reviews = $reviewController->listAllArticleReviews($review['article_id']);
                    ?>
                    <?php if (!empty($foreign_reviews)): ?>
                        <div class="other-reviews">
                            <strong>Další recenze:</strong>
                            <div class="other-reviews-list">
                                <?php foreach ($foreign_reviews as $f_review): ?>
                                    <div class="other-review">
                                        <?php
                                        $reviewer = $userController->getNameById($f_review['user_id']);
                                        echo $reviewer['name'] === $_SESSION['login'] ? "Moje recenze " : $reviewer['name'] . " " . $reviewer['surname'];

                                        $f_rating = (int)$f_review['total'];
                                        for ($i = 1; $i <= 5; $i++) {
                                            if ($i <= $f_rating) {
                                                echo '<i class="bi bi-star-fill text-warning" aria-hidden="true"></i>'; // plná hvězda
                                            } else {
                                                echo '<i class="bi bi-star text-muted" aria-hidden="true"></i>'; // prázdná hvězda
                                            }
                                        }
                                        ?>
                                    </div>
                                <?php endforeach; ?>
                                <div>
                                    <?php
                                    switch ($review['state']) {
                                        case 0:
                                            echo '<span class="badge bg-danger">Zamítnuta</span>';
                                            break;
                                        case 1:
                                            echo '<span class="badge bg-success">Schválena</span>';
                                            break;
                                        case 2:
                                            echo '<span class="badge bg-warning text-dark">Odevzdána</span>';
                                            break;
                                        case 3:
                                            echo '<span class="badge bg-info text-dark">Přidělena</span>';
                                            break;
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="article-info">
                        <strong>Článek:</strong>
                        <?= htmlspecialchars($currentArticle['article_name'] ?? 'NULL') ?><br>
                        <strong>Autor/Abstrakt:</strong>
                        <?= htmlspecialchars($currentArticle['abstract'] ?? 'NULL') ?><br>
                    </div>

                    <?php
                    // Normalize stored file path (remove leading ../ or ./ if present)
                    $downloadUrl = $currentArticle['file'] ?? '';
                    if (strpos($downloadUrl, '../') === 0) {
                        $downloadUrl = substr($downloadUrl, 3);
                    } elseif (strpos($downloadUrl, './') === 0) {
                        $downloadUrl = substr($downloadUrl, 2);
                    }
                    ?>

                    <a class="btn btn-outline-primary download-btn" href="<?= htmlspecialchars($downloadUrl) ?>" download>Stáhnout PDF</a>

                    <button class="btn btn-light toggle-review-btn">Recenzovat</button>

                    <form method="post" class="review-form" style="display: none;">
                        <input type="hidden" name="review_id" value="<?= htmlspecialchars($review['review_id']) ?>">
                        <hr>
                        <h4>Posuzované vlastnosti:</h4>

                        <label>Celkové hodnocení:
                            <input type="number" step="0.5" min="1" max="5" name="total" value="<?= htmlspecialchars($review['total'] ?? '') ?>">
                        </label><br>

                        <label>Jazyk:
                            <input type="number" step="0.5" min="1" max="5" name="language" value="<?= htmlspecialchars($review['language'] ?? '') ?>">
                        </label><br>

                        <label>Obsah:
                            <input type="number" step="0.5" min="1" max="5" name="content" value="<?= htmlspecialchars($review['content'] ?? '') ?>">
                        </label><br>

                        <label>Novost:
                            <input type="number" step="0.5" min="1" max="5" name="novelty" value="<?= htmlspecialchars($review['novelty'] ?? '') ?>">
                        </label><br><br>

                        <h4>Vlastní komentář:</h4>
                        <textarea name="comment" rows="4" cols="50"><?= htmlspecialchars($review['comment']) ?></textarea><br><br>

                        <button type="submit" class="btn btn-primary save-review-btn">Uložit recenzi</button>
                        <button type="button" class="btn btn-secondary cancel-review-btn">Zrušit</button>
                    </form>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>Žádné články nebyly nalezeny.</p>
    <?php echo $_SESSION['userId'] ?>
<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var buttons = document.querySelectorAll('.toggle-review-btn');

        buttons.forEach(function(button) {
            button.addEventListener('click', function() {
                var form = this.nextElementSibling;

                if (form.style.display === 'block') {
                    form.style.display = 'none';
                    this.textContent = 'Recenzovat';
                } else {
                    //otevri formular pokud si na nej kliknul
                    form.style.display = 'block';
                    this.textContent = 'Skrýt formulář';
                }
            });
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const buttons = document.querySelectorAll(".toggle-btn");

        buttons.forEach(button => {
            button.addEventListener("click", () => {
                const targetId = button.getAttribute("data-target");
                const target = document.getElementById(targetId);

                if (target.style.display === "none" || target.style.display === "") {
                    target.style.display = "block";
                    button.textContent = "Skrýt";
                } else {
                    target.style.display = "none";
                    button.textContent = "Zobrazit";
                }
            });
        });
    });
</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoYz1HkQK7U5q2b7rZl+3G1F5i5jv5Q5nQvZ6jIW3" crossorigin="anonymous"></script>
</body>
</html>
