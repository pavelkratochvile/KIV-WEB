<?php
    // session already started in front controller
    session_unset();
    session_destroy();
    header("Location: index.php?page=home");
?>
