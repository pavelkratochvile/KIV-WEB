-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pát 21. lis 2025, 16:54
-- Verze serveru: 10.4.32-MariaDB
-- Verze PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `mydb`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `article`
--

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_name` varchar(50) NOT NULL,
  `abstract` varchar(2000) NOT NULL,
  `state` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `authors` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vypisuji data pro tabulku `article`
--

INSERT INTO `article` (`article_id`, `user_id`, `article_name`, `abstract`, `state`, `file`, `authors`) VALUES
(37, 40, 'Pokročilé metody renderování ve fyzikálně založené', '<p><strong>Tento čl&aacute;nek se zab&yacute;v&aacute; nov&yacute;mi př&iacute;stupy k renderov&aacute;n&iacute; založen&eacute;mu na fyzik&aacute;ln&iacute;ch principech (Physically Based Rendering &ndash; PBR), kter&eacute; umožňuj&iacute; realistick&eacute; zobrazen&iacute; materi&aacute;lů a světeln&yacute;ch jevů ve 3D sc&eacute;n&aacute;ch. Představujeme metody pro přesněj&scaron;&iacute; simulaci &scaron;&iacute;řen&iacute; světla, modelov&aacute;n&iacute; povrchov&yacute;ch vlastnost&iacute; a optimalizaci v&yacute;početn&iacute; n&aacute;ročnosti pomoc&iacute; modern&iacute;ch GPU. Studie se soustřed&iacute; na kombinaci klasick&yacute;ch modelů osvětlov&aacute;n&iacute; s metodami path tracingu a importance samplingu. Důraz je kladen na vyv&aacute;žen&iacute; mezi vizu&aacute;ln&iacute; kvalitou a v&yacute;konem pro re&aacute;ln&eacute; aplikace v hern&iacute;m i filmov&eacute;m průmyslu. V&yacute;sledky ukazuj&iacute;, že využit&iacute; adaptivn&iacute;ch algoritmů může v&yacute;razně zkr&aacute;tit renderovac&iacute; časy bez ztr&aacute;ty kvality obrazu. Autoři navrhuj&iacute; r&aacute;mec pro dal&scaron;&iacute; rozvoj PBR syst&eacute;mů s využit&iacute;m strojov&eacute;ho učen&iacute;.&nbsp;</strong></p>\r\n', 2, '../pdf/FYA1_02.pdf', 'Ing. Jan Malík, Ph.D., Mgr. Klára Jásnká'),
(38, 41, 'Procedurální generování terénů pro herní engine', 'Tento článek představuje metody procedurálního generování terénů pomocí algoritmů Perlin Noise a Diamond-Square. V současných herních enginech se tyto přístupy využívají pro automatizovanou tvorbu realistických krajin s minimálním zásahem designéra. Studie analyzuje vliv parametrů šumu na vizuální kvalitu výsledného terénu, optimalizaci výpočtů na GPU a možnosti kombinace s fyzikální simulací. Dále je zkoumána možnost adaptivního level of detail (LOD) pro velké otevřené světy. Výsledky naznačují, že procedurální generování výrazně zvyšuje efektivitu produkce herních světů a umožňuje větší variabilitu prostředí.', 1, '../pdf/FYA1_02.pdf', 'Ing. Gustav Novotný, Bc. Monika Sedláčková'),
(40, 41, 'Vizualizace velkých dat pomocí GPU akcelerace', 'Vizualizace velkých dat (Big Data) je stále větší výzvou v současné informatice. Tento článek se zaměřuje na využití grafických procesorů (GPU) pro urychlení zpracování a vizualizace rozsáhlých datových sad. Prezentujeme architekturu CUDA a OpenCL a jejich aplikace v interaktivních nástrojích pro vědeckou vizualizaci. Experimentální výsledky prokazují až 20násobné zrychlení oproti klasickému CPU zpracování. Autoři popisují příklady z oblasti meteorologie, bioinformatiky a finanční analýzy, kde GPU akcelerace umožnila získat okamžitý vizuální přehled o strukturách v datech.', 0, '../pdf/FYA1_02.pdf', 'Ing. Gustav Novotný, Ph.D., Mgr. Alena Štěpánová'),
(41, 41, 'Optimalizovaná komprese a streaming 3D modelů pro ', 'Článek se zabývá optimalizovanými metodami komprese a přenosu 3D modelů pro webové aplikace. Popisujeme sadu technik zahrnující geometrii redukci, kvantizaci atributů a adaptivní streaming, které umožňují rychlé načítání a interaktivní prohlížení komplexních scén v prostředí omezené šířky pásma. Dále zkoumáme role server-side přípravy dat a klientské dekomprese s cílem minimalizovat latenci a zachovat věrnost zobrazovaných objektů. Prezentujeme experimenty porovnávající různé strategie kvantizace normál, texture atlasů a kompresních formátů, přičemž klademe důraz na kompromisy mezi velikostí souboru, vizuální kvalitou a výpočetní náročností klienta. Navrhujeme systém pro progresivní streaming, který umožňuje prioritizovat oblasti scény podle uživatelské pozice a zaměření, čímž zlepšuje vnímaný výkon a snižuje datové nároky při přechodech mezi scénami.', 1, '../pdf/FYA1_02.pdf', 'Ing. Gustav Novotný, Ph.D., Bc. Martina Zemanová'),
(42, 42, 'Stabilní simulace měkkých těles v reálném čase', 'Tento příspěvek se věnuje algoritmům pro simulaci měkkých těles a jejich integraci do reálného času fyzikálních enginů. Popisujeme numerické metody vhodné pro pružné modely, včetně stabilních schémat integrace, metod konstitutivního modelování materiálů a stabilizačních technik, které zabraňují artefaktům při vysokých deformacích. Zaměřujeme se na optimalizace pro paralelní výpočty na GPU a hybridní přístup kombinující částicové a mřížkové metody pro dosažení stabilního chování při zachování detailního vizuálního výstupu. V práci rovněž analyzujeme vliv různých parametrů materiálů na konvergenci a výpočetní náročnost, a navrhujeme adaptivní mesh-refinement pro lokální zvýšení přesnosti. Experimentální část porovnává náš přístup s vybranými referenčními metodami na sadě standardních scén s interakcí s tuhými tělesy a prostředím. Výsledky ukazují lepší poměr mezi přesností a výkonem a stabilitu v náročných situacích, například při kolizích a složitých kontaktech.', 2, '../pdf/FYA1_02.pdf', 'RNDr. Marek Vávra, Ph.D., Ing. Julie Slováčková'),
(43, 42, 'Generování a rekonstrukce textur s hlubokými sítěm', 'V článku prezentujeme metody pro syntézu a rekonstrukci textur vysokého rozlišení s využitím sítí hlubokého učení. Popisujeme architektury konvolučních a transformerových modelů schopných extrapolovat textury z malých vzorků a generovat konzistentní mapy normál, odlesků a povrchových detailů. Zaměřujeme se na problém zachování strukturální konzistence, eliminace opakování a úpravy pro různé materiálové charakteristiky. Navrhujeme ztrátové funkce kombinující perceptuální, stylové a fyzikálně inspirované komponenty pro dosažení realistických výstupů. Implementace využívá techniky úsporného tréninku a distilace, aby byla síť vhodná pro nasazení v produkčních prostředích s omezenými prostředky. Studie obsahuje srovnání s konvenčními metodami syntézy textur a ukazuje významné zlepšení v oblasti vizuální věrohodnosti a adaptibilitě na rozdílné měřítka.', 2, '../pdf/FYA1_02.pdf', 'Mgr. Ivana Svobodová, Ing. Julie Slováčková'),
(44, 42, 'Interpretabilita a vysvětlitelnost modelů v grafic', 'Článek se zabývá problematikou nástrojů pro interpretabilitu a vysvětlitelnost v aplikacích počítačové grafiky, zejména tam, kde jsou využity modely strojového učení pro rozhodování ve vizualizačních procesech. Popisujeme metodologie pro auditování modelů, vizualizaci rozhodovacích kritérií a metody pro detekci biasu a nežádoucích artefaktů ve výstupu. Navrhujeme sadu metrik pro hodnocení transparentnosti modelů a workflow, který umožňuje vývojářům i koncovým uživatelům pochopit, proč dané vizualizační volby byly provedeny. Příspěvek taktéž uvádí techniky mapování chybové citlivosti a vizualizace neurčitosti v generovaných obrazech a 3D datech, což je zásadní pro aplikace v medicíně, bezpečnostních systémech a vědeckých simulacích. V praktické části prezentujeme případové studie, kde jsou navržené metody aplikovány na scénáře z biomedicínské vizualizace a autonomního řízení. Diskutujeme etické a regulační důsledky nasazení black-box modelů v kritických oblastech a navrhujeme doporučení pro odpovědné používání, včetně verzování modelů, dokumentace datových sad a rutinních testů robustnosti. Dále popisujeme nástroje pro interaktivní inspekci modelů, které umožňují zkoumání vstupních vlivů a jejich dopadu na finální vizualizační rozhodnutí.', 1, '../pdf/FYA1_02.pdf', 'Prof. RNDr. Helena Kovářová, Ph.D., Ing. Julie Slováčková'),
(62, 40, 'e', 'ee', 2, 'pdf/ZOS2024_SP_1763622503.pdf', 'e'),
(63, 40, 'ddd', 'adsd', 2, 'pdf/FYA1_02__3__1763642267.pdf', 'd');

-- --------------------------------------------------------

--
-- Struktura tabulky `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `total` int(11) DEFAULT NULL,
  `language` int(11) DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `novelty` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `state` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vypisuji data pro tabulku `review`
--

INSERT INTO `review` (`review_id`, `user_id`, `article_id`, `total`, `language`, `content`, `novelty`, `comment`, `state`) VALUES
(65, 43, 37, 4, 4, 4, 4, 'Autoři zvolili zajímavé téma s aktuálním dopadem v praxi. Popis experimentální části je však místy stručný. Doporučuji rozšířit diskusi o omezení navrženého přístupu. Styl psaní je jasný a srozumitelný. eeeeeeeeeeeeeessss', 2),
(66, 45, 40, 5, 5, 5, 5, 'Příspěvek přináší zajímavý teoretický příspěvek s potenciálními aplikacemi. Některé části jsou však příliš stručné a vyžadují detailnější vysvětlení parametrů a implementačních kroků. Doporučuji doplnit ukázkové případy použití a rozšířit srovnání s exist', 2),
(67, 43, 44, 1, 1, 1, 1, 'Práce je kvalitně zpracovaná a teoretický základ je velmi dobře zdokumentován. Výsledky jsou přesvědčivé a odpovídají stanoveným cílům. V části o aplikacích by bylo vhodné uvést konkrétní příklady z praxe. Doporučuji přijmout k publikaci po menších doplně', 2),
(68, 44, 44, 4, 2, 2, 2, 'Autoři se zaměřili na aktuální problém, který má praktické využití. Výsledky experimentů potvrzují správnost jejich hypotéz. Styl psaní je akademický a přehledný. Doporučuji drobné jazykové úpravy a doplnění literatury. Jinak kvalitní práce s potenciálem ', 2),
(69, 44, 42, 5, 5, 5, 5, 'ráce se vyznačuje vysokou úrovní odbornosti a precizním zpracováním. Experimentální výsledky jsou podrobně popsány a správně interpretovány. Doporučuji zvážit rozšíření části o možných aplikacích. Po drobných úpravách je článek plně vhodný pro publikaci.', 2),
(70, 44, 43, NULL, NULL, NULL, NULL, NULL, 3),
(71, 43, 43, 5, 5, 5, 5, 'Článek se zaměřuje na inovativní využití strojového učení v počítačové grafice. Přístup autorů je originální a výsledky jsou slibné. Některé části by však zasloužily detailnější vysvětlení. Přínos práce je nesporný a otevírá prostor pro další výzkum v tét', 2),
(72, 45, 44, NULL, NULL, NULL, NULL, NULL, 3),
(73, 43, 41, 3, 3, 3, 3, 'Zpracování článku je pečlivé, text je logicky členěn a dobře se čte. Přesto by bylo vhodné doplnit více technických detailů a zmínit limity navržené metody. Obrázky a tabulky jsou přehledné. Celkově jde o solidní výzkumný příspěvek, který stojí za publika', 2),
(74, 44, 41, NULL, NULL, NULL, NULL, NULL, 3),
(75, 45, 41, 4, 4, 3, 4, 'Výzkum je systematicky provedený a struktura článku přehledná. Autoři prezentují jasné závěry podložené daty. Bylo by vhodné přidat error analysis a diskutovat robustnost metody vůči šumu v datech. S těmito doplňky jde o velmi hodnotný vědecký příspěvek.', 2),
(78, 43, 42, NULL, NULL, NULL, NULL, NULL, 3),
(79, 43, 38, NULL, NULL, NULL, NULL, NULL, 3),
(83, 44, 38, NULL, NULL, NULL, NULL, NULL, 3),
(86, 44, 37, NULL, NULL, NULL, NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Struktura tabulky `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vypisuji data pro tabulku `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(1, 'Ucastnik'),
(2, 'Recenzent'),
(3, 'Admin'),
(4, 'Superadmin');

-- --------------------------------------------------------

--
-- Struktura tabulky `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `surname` varchar(25) NOT NULL,
  `login` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` char(255) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vypisuji data pro tabulku `user`
--

INSERT INTO `user` (`user_id`, `name`, `surname`, `login`, `email`, `password`, `role_id`) VALUES
(36, 'Jan', 'Novák', 'jnovak', 'jan.novak@gmail.com', '$2y$10$V03pH0dZ5gHcuxiZaG.up.DrCSLxZLC1ja44eq.YcZ/m9jJnPEluy', 4),
(37, 'Karel', 'Veselý', 'veselykarel', 'karel.vesely@gmail.com', '$2y$10$/rRtAKYNteUPLZHBIS1N2u640iIfhhpf6oXpuOKutXi2oFO6fTmh2', 3),
(38, 'František', 'Balavec', 'Belavecc', 'frantisek.balavec@gmail.c', '$2y$10$xA5r.7SmniILsqqCopsawODsTKvCcYg6n.Ra6atjyiu18N.Qn6kua', 3),
(39, 'Václav', 'Tauš', 'Tausiiino', 'vaclav.taus@gmail.com', '$2y$10$UYOoLwp0r.kSOhcTuaj01em6o0kXvBfgTwSgCVdAj8TuK1XxbyXa.', 3),
(40, 'Klára', 'Jánská', 'keria', 'klara.janska@gmail.com', '$2y$10$BpXXHTVaCwY8Z2A1DH6CDOCD7knAQdSbqFMn.V55QEDZmKwUIE3Am', 1),
(41, 'Gustav', 'Novotný', 'novotny', 'gustav.novotny@gmail.com', '$2y$10$HPv1Zh.ZrrUYP1CI5GUIp.L9a9yKIRriZp2Fa4gM4bTBKpqrsHLBu', 1),
(42, 'Julie', 'Slováčková', 'rebel', 'julie.slovackova@gmail.co', '$2y$10$gdGu1nBgsj8DuiNxdUK2U.iLwrQtg8fDDTixnuGC6Nk2jvIZ.PWpu', 1),
(43, 'Jaroslav', 'Kužel', 'kuzelj', 'jaroslav.kuzel@gmail.com', '$2y$10$KMJ6GJTgQu5UhnxBy9idZO.6jWcs5e70NUxdMYbLaYYPwSYUlFQim', 2),
(44, 'Josef', 'Hnátek', 'hnata', 'josef.hnatek@gmail.com', '$2y$10$zzfkomP3qkGgirI32AZaROS6NUb9GO2RHlv6vxboETUaR35rpJiW.', 2),
(45, 'Dagmar', 'Karasová', 'KaryKaras', 'dagmar.karasova@gmail.com', '$2y$10$hYAapmp9r0cImDoYtDiKUOOhfsSkj20bXM03vSZOuJyEnvebIrmCO', 2);

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `article-user` (`user_id`);

--
-- Indexy pro tabulku `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `review-user` (`user_id`),
  ADD KEY `review-article` (`article_id`);

--
-- Indexy pro tabulku `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexy pro tabulku `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user-role` (`role_id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `article`
--
ALTER TABLE `article`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT pro tabulku `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT pro tabulku `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pro tabulku `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article-user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Omezení pro tabulku `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review-article` FOREIGN KEY (`article_id`) REFERENCES `article` (`article_id`),
  ADD CONSTRAINT `review-user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Omezení pro tabulku `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user-role` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
